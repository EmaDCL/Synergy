package com.proaula.spring.synergy.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class AuthWebController {


}

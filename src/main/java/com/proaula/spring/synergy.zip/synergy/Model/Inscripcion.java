package com.proaula.spring.synergy.Model;

public class Inscripcion {

}

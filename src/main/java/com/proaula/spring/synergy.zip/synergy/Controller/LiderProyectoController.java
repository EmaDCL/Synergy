package com.proaula.spring.synergy.Controller;

public class LiderProyectoController {
    
}
